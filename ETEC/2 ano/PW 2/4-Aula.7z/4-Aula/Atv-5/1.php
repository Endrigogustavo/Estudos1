<html>
<head>
    
    
</head>
<body>
    <?php

    
    $num1 = $_POST['num'];
    $num2 = $_POST['num2'];
    $num3 = $_POST['num3'];
   
    $res1 = $num1 ** 2;
    $res2 = $num2 ** 2;
    $res3 = $num3 ** 2;
    
    echo $res1;
    echo "<br>";
    echo $res2;
    echo "<br>";
    echo $res3;
    
       
    

    ?>
</body>
</html>