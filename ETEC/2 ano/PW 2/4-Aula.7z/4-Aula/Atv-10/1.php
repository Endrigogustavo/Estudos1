<html>
<head>
    
    
</head>
<body>
    <?php


    $num1 = $_POST['num1'];
   
    if($num1 %2 != 0){
        echo "o numero é impar";
    }
    else{
        echo "o numero e par";
    }
    ?>
</body>
</html>